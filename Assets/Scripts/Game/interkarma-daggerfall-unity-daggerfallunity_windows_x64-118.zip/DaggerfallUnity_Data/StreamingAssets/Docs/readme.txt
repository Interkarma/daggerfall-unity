This folder can be used to store documentation files that are shipped with a mod.
This ensures that mod packages can be installed with Vortex or manually extracted to StreamingAssets
without unintentionally overwriting files named readme.txt inside Mods or other folders.

Mod documentation should be a text file or a folder named as the title of the mod.