Place custom sound font .SF2 files into this folder then set SoundFont=filename.sf2 in settings.ini

Note: Not all sound fonts are loaded successfully. Player will automatically fall back to default
font if custom file cannot be loaded.