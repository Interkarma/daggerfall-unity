Place any loose texture file replacements into this folder.

To create your own texture replacements, please see the following URL for more information on naming texture files.
http://www.dfworkshop.net/projects/daggerfall-unity/modding/textures/