var class_smart_localization_1_1_editor_1_1_h_o_editor_undo_manager =
[
    [ "HOEditorUndoManager", "class_smart_localization_1_1_editor_1_1_h_o_editor_undo_manager.html#a2a1a772565da93c37637582d07f52773", null ],
    [ "HOEditorUndoManager", "class_smart_localization_1_1_editor_1_1_h_o_editor_undo_manager.html#a0e026b99e36e24d8249fecbe429814b3", null ],
    [ "CheckDirty", "class_smart_localization_1_1_editor_1_1_h_o_editor_undo_manager.html#a9ce9049a8c5f6e6b3a8a9d68c987b8cc", null ],
    [ "CheckDirty", "class_smart_localization_1_1_editor_1_1_h_o_editor_undo_manager.html#afc72b51f688d4d1a35ab4ebbae5ee330", null ],
    [ "CheckDirty", "class_smart_localization_1_1_editor_1_1_h_o_editor_undo_manager.html#a85b66d39a418c2af0354434d2d80e030", null ],
    [ "CheckUndo", "class_smart_localization_1_1_editor_1_1_h_o_editor_undo_manager.html#a2a0990de73bc9cad77bffc814e92236f", null ],
    [ "CheckUndo", "class_smart_localization_1_1_editor_1_1_h_o_editor_undo_manager.html#ae03387049f69f1583ce2f32a56b0334b", null ],
    [ "CheckUndo", "class_smart_localization_1_1_editor_1_1_h_o_editor_undo_manager.html#a5543fb3672a404e40a78557608a40f1f", null ],
    [ "ForceDirty", "class_smart_localization_1_1_editor_1_1_h_o_editor_undo_manager.html#a29f16d734c17a89899c71790936ae663", null ],
    [ "ForceDirty", "class_smart_localization_1_1_editor_1_1_h_o_editor_undo_manager.html#ad68b66c80852a7a5c5056d0edbfcf9c0", null ],
    [ "ForceDirty", "class_smart_localization_1_1_editor_1_1_h_o_editor_undo_manager.html#a82e510f3fab2dfe9efdcb0d81845c8ce", null ]
];