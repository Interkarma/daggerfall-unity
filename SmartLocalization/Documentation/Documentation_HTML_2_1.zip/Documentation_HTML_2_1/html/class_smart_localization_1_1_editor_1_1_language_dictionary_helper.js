var class_smart_localization_1_1_editor_1_1_language_dictionary_helper =
[
    [ "AddNewKeyPersistent", "class_smart_localization_1_1_editor_1_1_language_dictionary_helper.html#a85b3596487285c5b929b351884aee271", null ],
    [ "AddNewKeyPersistent", "class_smart_localization_1_1_editor_1_1_language_dictionary_helper.html#afda41cd5ca341227d9c4e860a763c3ed", null ]
];