var class_smart_localization_1_1_reorderable_list_1_1_item_inserted_event_args =
[
    [ "ItemInsertedEventArgs", "class_smart_localization_1_1_reorderable_list_1_1_item_inserted_event_args.html#a609800fe09df8db71e0119bd172a4d6e", null ],
    [ "adaptor", "class_smart_localization_1_1_reorderable_list_1_1_item_inserted_event_args.html#ab7ff8cb0deb95e7ed1b86590f89310ba", null ],
    [ "itemIndex", "class_smart_localization_1_1_reorderable_list_1_1_item_inserted_event_args.html#afd45a099a771838508f7c57b7272badc", null ],
    [ "wasDuplicated", "class_smart_localization_1_1_reorderable_list_1_1_item_inserted_event_args.html#ae2e3db64eb5f8d9f0fd458841970f6e5", null ]
];