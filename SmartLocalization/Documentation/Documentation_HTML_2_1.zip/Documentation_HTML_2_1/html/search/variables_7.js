var searchData=
[
  ['onchangelanguage',['OnChangeLanguage',['../class_smart_localization_1_1_language_manager.html#a73b2faa170698e77831d8efb778761d7',1,'SmartLocalization::LanguageManager']]]
];
