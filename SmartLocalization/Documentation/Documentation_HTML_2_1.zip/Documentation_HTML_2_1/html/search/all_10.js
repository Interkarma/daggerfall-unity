var searchData=
[
  ['tab',['TAB',['../namespace_smart_localization_1_1_editor.html#a5781827f1d50ce14c62369d109fa27e9af684bf05fa3e81528c84d1d281d839f1',1,'SmartLocalization::Editor']]],
  ['texturesfolderpath',['TexturesFolderPath',['../class_smart_localization_1_1_language_runtime_data.html#a6ffe0435e96afcc36e80678b21dd3fad',1,'SmartLocalization::LanguageRuntimeData']]],
  ['textvalue',['TextValue',['../class_smart_localization_1_1_localized_object.html#aa97c3403f6013ec019cb04c801e276d7',1,'SmartLocalization::LocalizedObject']]],
  ['thisaudioclip',['ThisAudioClip',['../class_smart_localization_1_1_localized_object.html#a7a89a004cd688c31ebbc5d99c77a244b',1,'SmartLocalization::LocalizedObject']]],
  ['thisgameobject',['ThisGameObject',['../class_smart_localization_1_1_localized_object.html#a3e8365758d47dc7b5ea919cc797e85fe',1,'SmartLocalization::LocalizedObject']]],
  ['thistexture',['ThisTexture',['../class_smart_localization_1_1_localized_object.html#a148a1873d4bcba69cec955aa01428710',1,'SmartLocalization::LocalizedObject']]],
  ['translatelanguagewindow',['TranslateLanguageWindow',['../class_smart_localization_1_1_editor_1_1_translate_language_window.html',1,'SmartLocalization::Editor']]],
  ['translatetext',['TranslateText',['../interface_smart_localization_1_1_editor_1_1_i_automatic_translator.html#a9dc6bf513b6a5da5e8d658129e6e8e13',1,'SmartLocalization.Editor.IAutomaticTranslator.TranslateText()'],['../class_smart_localization_1_1_editor_1_1_microsoft_automatic_translator.html#aed778e2e982b3f021b4f42139912af13',1,'SmartLocalization.Editor.MicrosoftAutomaticTranslator.TranslateText()']]],
  ['translatetextarray',['TranslateTextArray',['../interface_smart_localization_1_1_editor_1_1_i_automatic_translator.html#a8c6405dc510671d5ed92099456f0e42c',1,'SmartLocalization.Editor.IAutomaticTranslator.TranslateTextArray()'],['../class_smart_localization_1_1_editor_1_1_microsoft_automatic_translator.html#a50a6db51a3140bf1b5dc3186712bcf1a',1,'SmartLocalization.Editor.MicrosoftAutomaticTranslator.TranslateTextArray()']]],
  ['translatetextarrayeventhandler',['TranslateTextArrayEventHandler',['../namespace_smart_localization_1_1_editor.html#a9b999109c51fe2a6b282af2f66d30215',1,'SmartLocalization::Editor']]],
  ['translatetexteventhandler',['TranslateTextEventHandler',['../namespace_smart_localization_1_1_editor.html#a2646dd5e6439e3316f1f42e359e1f2f9',1,'SmartLocalization::Editor']]],
  ['txtfileending',['txtFileEnding',['../class_smart_localization_1_1_editor_1_1_localization_workspace.html#ab4354cc2c6bbf0dba2cffaeef92b58ed',1,'SmartLocalization::Editor::LocalizationWorkspace']]],
  ['type',['TYPE',['../namespace_smart_localization_1_1_editor.html#ac8fe93714abb1932682a8367349498dea948495146facadfe8859789036313d79',1,'SmartLocalization::Editor']]]
];
