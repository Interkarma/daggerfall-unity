var searchData=
[
  ['prefabsfolderpath',['PrefabsFolderPath',['../class_smart_localization_1_1_language_runtime_data.html#a2ea7aa7d8f95cd70df5fb0cca4df8de6',1,'SmartLocalization::LanguageRuntimeData']]]
];
