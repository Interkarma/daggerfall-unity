var searchData=
[
  ['generatestorepresence',['GenerateStorePresence',['../class_smart_localization_1_1_editor_1_1_android_store_presence_generator.html#ad166fa449bbd84132eb5ce970c77fa7b',1,'SmartLocalization.Editor.AndroidStorePresenceGenerator.GenerateStorePresence()'],['../class_smart_localization_1_1_editor_1_1_i_o_s_store_presence_generator.html#ae53c1a51db26b2737aaad1bdbd53de86',1,'SmartLocalization.Editor.IOSStorePresenceGenerator.GenerateStorePresence()']]]
];
