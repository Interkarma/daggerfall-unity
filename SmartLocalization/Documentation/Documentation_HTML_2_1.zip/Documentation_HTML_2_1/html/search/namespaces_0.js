var searchData=
[
  ['editor',['Editor',['../namespace_smart_localization_1_1_editor.html',1,'SmartLocalization']]],
  ['smartlocalization',['SmartLocalization',['../namespace_smart_localization.html',1,'']]]
];
