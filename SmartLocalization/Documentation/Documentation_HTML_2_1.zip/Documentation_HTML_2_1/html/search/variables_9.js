var searchData=
[
  ['resxfileending',['resXFileEnding',['../class_smart_localization_1_1_editor_1_1_localization_workspace.html#a8c06b09a727b9bc7e0499db58b4591c2',1,'SmartLocalization::Editor::LocalizationWorkspace']]],
  ['rootlanguagename',['rootLanguageName',['../class_smart_localization_1_1_editor_1_1_localization_workspace.html#a1255294ca1f58d212e7283d83c5ca478',1,'SmartLocalization::Editor::LocalizationWorkspace']]]
];
