var searchData=
[
  ['objecttype',['ObjectType',['../class_smart_localization_1_1_localized_object.html#a1a9d88fc5e2f00b95fbc1b0b7400d687',1,'SmartLocalization::LocalizedObject']]]
];
