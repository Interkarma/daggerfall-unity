var searchData=
[
  ['datafolderpath',['DataFolderPath',['../class_smart_localization_1_1_editor_1_1_localization_workspace.html#a310c05b4c4f5f22490083c569d66e95a',1,'SmartLocalization::Editor::LocalizationWorkspace']]],
  ['defaultlanguage',['defaultLanguage',['../class_smart_localization_1_1_language_manager.html#ac0b8d2d1530ac8066eb9f11c7ee711de',1,'SmartLocalization::LanguageManager']]],
  ['delete',['Delete',['../class_smart_localization_1_1_editor_1_1_file_utility.html#ad6283be4bdff7be0169cb6a7d651e335',1,'SmartLocalization::Editor::FileUtility']]],
  ['deletefilefromresources',['DeleteFileFromResources',['../class_smart_localization_1_1_editor_1_1_language_handler_editor.html#ad92fc23040c2e732c7059572cc44024e',1,'SmartLocalization::Editor::LanguageHandlerEditor']]],
  ['deletelanguage',['DeleteLanguage',['../class_smart_localization_1_1_editor_1_1_language_handler_editor.html#a56657a3d046b05dc8c47a7e5b3a0cc0a',1,'SmartLocalization::Editor::LanguageHandlerEditor']]],
  ['deserialize',['Deserialize',['../class_smart_localization_1_1_editor_1_1_smart_culture_info_ex.html#ae1298a7bcee2ca300fe5ff7d6416fa82',1,'SmartLocalization.Editor.SmartCultureInfoEx.Deserialize()'],['../class_smart_localization_1_1_smart_culture_info_collection.html#a20cc5b233accdfbdb72c9527aec266d9',1,'SmartLocalization.SmartCultureInfoCollection.Deserialize()']]],
  ['directoryutility',['DirectoryUtility',['../class_smart_localization_1_1_editor_1_1_directory_utility.html',1,'SmartLocalization::Editor']]]
];
