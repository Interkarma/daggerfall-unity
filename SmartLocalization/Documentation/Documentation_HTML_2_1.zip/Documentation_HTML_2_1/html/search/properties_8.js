var searchData=
[
  ['verboselogging',['VerboseLogging',['../class_smart_localization_1_1_language_manager.html#a089a01a0cbeb22de72790d27fc334768',1,'SmartLocalization::LanguageManager']]]
];
