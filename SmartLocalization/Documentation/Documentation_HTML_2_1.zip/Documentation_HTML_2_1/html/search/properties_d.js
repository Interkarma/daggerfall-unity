var searchData=
[
  ['wasduplicated',['wasDuplicated',['../class_smart_localization_1_1_reorderable_list_1_1_item_inserted_event_args.html#ae2e3db64eb5f8d9f0fd458841970f6e5',1,'SmartLocalization::ReorderableList::ItemInsertedEventArgs']]]
];
