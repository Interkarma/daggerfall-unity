var searchData=
[
  ['key',['KEY',['../namespace_smart_localization_1_1_editor.html#a44658bbcee7063b8c72f2acff768db50a3b5949e0c26b87767a4752a276de9570',1,'SmartLocalization.Editor.KEY()'],['../namespace_smart_localization_1_1_editor.html#ac8fe93714abb1932682a8367349498dea3b5949e0c26b87767a4752a276de9570',1,'SmartLocalization.Editor.KEY()']]],
  ['keytypeidentifier',['keyTypeIdentifier',['../class_smart_localization_1_1_localized_object.html#af720ac31ca097bf5a99da91ad7577aa2',1,'SmartLocalization::LocalizedObject']]]
];
