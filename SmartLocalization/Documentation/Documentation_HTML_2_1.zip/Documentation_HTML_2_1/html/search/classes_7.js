var searchData=
[
  ['microsoftautomatictranslator',['MicrosoftAutomaticTranslator',['../class_smart_localization_1_1_editor_1_1_microsoft_automatic_translator.html',1,'SmartLocalization::Editor']]]
];
