var searchData=
[
  ['targetbackgroundcolor',['TargetBackgroundColor',['../class_smart_localization_1_1_reorderable_list_1_1_reorderable_list_control.html#ad52d79cc1ede6f995b0b032077b7037c',1,'SmartLocalization::ReorderableList::ReorderableListControl']]],
  ['txtfileending',['txtFileEnding',['../class_smart_localization_1_1_editor_1_1_localization_workspace.html#ab4354cc2c6bbf0dba2cffaeef92b58ed',1,'SmartLocalization::Editor::LocalizationWorkspace']]]
];
