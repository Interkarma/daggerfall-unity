var searchData=
[
  ['rawtextdatabase',['RawTextDatabase',['../class_smart_localization_1_1_language_manager.html#a1db4ebceced81465ac0e7fba9d27d3bf',1,'SmartLocalization::LanguageManager']]],
  ['removebuttonstyle',['removeButtonStyle',['../class_smart_localization_1_1_reorderable_list_1_1_reorderable_list_control.html#ac5f93267a66828d81d54f4a3e98fa3d5',1,'SmartLocalization::ReorderableList::ReorderableListControl']]]
];
