var searchData=
[
  ['oninspectorgui',['OnInspectorGUI',['../class_smart_localization_1_1_editor_1_1_localized_audio_source_inspector.html#ac9a7acdd2d6c3d03dfd2df6e9e8dfb47',1,'SmartLocalization.Editor.LocalizedAudioSourceInspector.OnInspectorGUI()'],['../class_smart_localization_1_1_editor_1_1_localized_g_u_i_text_inspector.html#a4b4cb46e7179d1c4ec4a81069a354549',1,'SmartLocalization.Editor.LocalizedGUITextInspector.OnInspectorGUI()'],['../class_smart_localization_1_1_editor_1_1_localized_g_u_i_texture_inspector.html#a879568386b9609a945d58647f9f57c2c',1,'SmartLocalization.Editor.LocalizedGUITextureInspector.OnInspectorGUI()']]],
  ['onpostprocessallassets',['OnPostprocessAllAssets',['../class_smart_localization_1_1_editor_1_1_custom_resx_importer.html#af4cc7b3ca305b11d9ece23747aaa6045',1,'SmartLocalization::Editor::CustomResxImporter']]],
  ['onpostprocessbuild',['OnPostProcessBuild',['../class_smart_localization_1_1_editor_1_1_i_o_s_store_presence_generator.html#ae448517c00ef05c606ceb813c7d53830',1,'SmartLocalization::Editor::IOSStorePresenceGenerator']]]
];
