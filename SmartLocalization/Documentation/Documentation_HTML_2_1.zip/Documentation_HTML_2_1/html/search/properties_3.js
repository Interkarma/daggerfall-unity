var searchData=
[
  ['languagedatabase',['LanguageDatabase',['../class_smart_localization_1_1_language_manager.html#a3aee64ac25270e9d23f66d37cf3975cc',1,'SmartLocalization::LanguageManager']]],
  ['loadedlanguage',['LoadedLanguage',['../class_smart_localization_1_1_language_manager.html#a508f24bc3a9ebc3079f0603ce963d2ab',1,'SmartLocalization::LanguageManager']]]
];
