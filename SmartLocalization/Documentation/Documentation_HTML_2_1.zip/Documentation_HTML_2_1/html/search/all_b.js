var searchData=
[
  ['nativename',['nativeName',['../class_smart_localization_1_1_smart_culture_info.html#aabd10ea163d66641540d09ed1e24025f',1,'SmartLocalization::SmartCultureInfo']]],
  ['numberofsupportedlanguages',['NumberOfSupportedLanguages',['../class_smart_localization_1_1_language_manager.html#ae3647009233cec178defb6be93af48ce',1,'SmartLocalization::LanguageManager']]]
];
