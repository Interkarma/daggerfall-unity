var searchData=
[
  ['parsedrootvalues',['parsedRootValues',['../class_smart_localization_1_1_editor_1_1_edit_root_language_file_window.html#a2fdea68273f813288e108ac067de30ea',1,'SmartLocalization::Editor::EditRootLanguageFileWindow']]],
  ['prefabfileending',['prefabFileEnding',['../class_smart_localization_1_1_editor_1_1_localization_workspace.html#aac27cdc5da26ca3bd04466aae2675781',1,'SmartLocalization::Editor::LocalizationWorkspace']]]
];
