var searchData=
[
  ['androidstorepresencegenerator',['AndroidStorePresenceGenerator',['../class_smart_localization_1_1_editor_1_1_android_store_presence_generator.html',1,'SmartLocalization::Editor']]]
];
