var searchData=
[
  ['parsedrootvalues',['parsedRootValues',['../class_smart_localization_1_1_editor_1_1_edit_root_language_file_window.html#a2fdea68273f813288e108ac067de30ea',1,'SmartLocalization::Editor::EditRootLanguageFileWindow']]],
  ['prefabfileending',['prefabFileEnding',['../class_smart_localization_1_1_editor_1_1_localization_workspace.html#aac27cdc5da26ca3bd04466aae2675781',1,'SmartLocalization::Editor::LocalizationWorkspace']]],
  ['prefabsfolderpath',['PrefabsFolderPath',['../class_smart_localization_1_1_language_runtime_data.html#a2ea7aa7d8f95cd70df5fb0cca4df8de6',1,'SmartLocalization::LanguageRuntimeData']]]
];
