var class_smart_localization_1_1_localized_audio_source =
[
    [ "localizedKey", "class_smart_localization_1_1_localized_audio_source.html#abce0b4fbdc0ebc8f89348b997fd5e248", null ],
    [ "thisAudioClip", "class_smart_localization_1_1_localized_audio_source.html#a59843639138ed94f3e55c76b4ad1dcf8", null ]
];