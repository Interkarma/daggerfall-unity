var class_smart_localization_1_1_language_runtime_data =
[
    [ "AudioFilesFolderPath", "class_smart_localization_1_1_language_runtime_data.html#a9a8d7c3bb786c3a1452f19c80acc6c95", null ],
    [ "AvailableCulturesFilePath", "class_smart_localization_1_1_language_runtime_data.html#a6312fd16e3d8168264d963aad61e85c1", null ],
    [ "LanguageFilePath", "class_smart_localization_1_1_language_runtime_data.html#a3925a393279554cdb4c95b3d8dd1abf5", null ],
    [ "PrefabsFolderPath", "class_smart_localization_1_1_language_runtime_data.html#a2ea7aa7d8f95cd70df5fb0cca4df8de6", null ],
    [ "TexturesFolderPath", "class_smart_localization_1_1_language_runtime_data.html#a6ffe0435e96afcc36e80678b21dd3fad", null ]
];