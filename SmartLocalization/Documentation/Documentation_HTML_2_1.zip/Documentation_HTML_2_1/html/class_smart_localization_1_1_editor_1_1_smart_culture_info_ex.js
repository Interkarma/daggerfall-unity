var class_smart_localization_1_1_editor_1_1_smart_culture_info_ex =
[
    [ "Deserialize", "class_smart_localization_1_1_editor_1_1_smart_culture_info_ex.html#ae1298a7bcee2ca300fe5ff7d6416fa82", null ],
    [ "Serialize", "class_smart_localization_1_1_editor_1_1_smart_culture_info_ex.html#a034cde8060319581b45ce775748f9098", null ]
];