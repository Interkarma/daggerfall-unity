var class_smart_localization_1_1_editor_1_1_c_s_v_import_window =
[
    [ "ShowWindow", "class_smart_localization_1_1_editor_1_1_c_s_v_import_window.html#a67a249e589050059068d4f4dc812ee0e", null ],
    [ "chosenCulture", "class_smart_localization_1_1_editor_1_1_c_s_v_import_window.html#a56e087ba6a7538098772494935ddfc82", null ],
    [ "creationDelegate", "class_smart_localization_1_1_editor_1_1_c_s_v_import_window.html#a9f1eebad161abf9414849d56c6ef97d0", null ],
    [ "delimiter", "class_smart_localization_1_1_editor_1_1_c_s_v_import_window.html#a4b6092f173a14295378af1a323ef1359", null ]
];