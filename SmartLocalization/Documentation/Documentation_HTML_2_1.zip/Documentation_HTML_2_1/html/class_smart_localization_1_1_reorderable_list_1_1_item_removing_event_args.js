var class_smart_localization_1_1_reorderable_list_1_1_item_removing_event_args =
[
    [ "ItemRemovingEventArgs", "class_smart_localization_1_1_reorderable_list_1_1_item_removing_event_args.html#a62d90568bcb7ec92aae37768ca0b9deb", null ],
    [ "adaptor", "class_smart_localization_1_1_reorderable_list_1_1_item_removing_event_args.html#a55986b587b23070f9f82dd06d993b429", null ],
    [ "itemIndex", "class_smart_localization_1_1_reorderable_list_1_1_item_removing_event_args.html#ad33075621c21dd34615f156a8b247cac", null ]
];