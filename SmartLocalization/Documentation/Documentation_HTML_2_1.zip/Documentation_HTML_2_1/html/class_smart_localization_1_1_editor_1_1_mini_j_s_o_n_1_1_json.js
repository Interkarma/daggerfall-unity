var class_smart_localization_1_1_editor_1_1_mini_j_s_o_n_1_1_json =
[
    [ "Deserialize", "class_smart_localization_1_1_editor_1_1_mini_j_s_o_n_1_1_json.html#ac6e9ad35834ac855cbed3ca7a2c59f87", null ],
    [ "Serialize", "class_smart_localization_1_1_editor_1_1_mini_j_s_o_n_1_1_json.html#a4066197d43a6aee0277c588a234fe3dc", null ]
];