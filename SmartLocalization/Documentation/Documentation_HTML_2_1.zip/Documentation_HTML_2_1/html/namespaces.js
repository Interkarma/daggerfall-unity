var namespaces =
[
    [ "SmartLocalization", "namespace_smart_localization.html", "namespace_smart_localization" ]
];