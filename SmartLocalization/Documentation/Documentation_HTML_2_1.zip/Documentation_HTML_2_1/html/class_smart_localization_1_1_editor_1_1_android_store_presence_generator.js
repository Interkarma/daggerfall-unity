var class_smart_localization_1_1_editor_1_1_android_store_presence_generator =
[
    [ "GeneratePresence", "class_smart_localization_1_1_editor_1_1_android_store_presence_generator.html#acbe7c890ce216deb948460a3f62b31ca", null ],
    [ "GenerateStorePresence", "class_smart_localization_1_1_editor_1_1_android_store_presence_generator.html#ad166fa449bbd84132eb5ce970c77fa7b", null ],
    [ "HasStorePresence", "class_smart_localization_1_1_editor_1_1_android_store_presence_generator.html#ae66e13a2ac98ec3889723531df5d1153", null ]
];