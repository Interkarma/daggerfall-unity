var class_smart_localization_1_1_editor_1_1_localized_g_u_i_texture_inspector =
[
    [ "OnInspectorGUI", "class_smart_localization_1_1_editor_1_1_localized_g_u_i_texture_inspector.html#a879568386b9609a945d58647f9f57c2c", null ]
];