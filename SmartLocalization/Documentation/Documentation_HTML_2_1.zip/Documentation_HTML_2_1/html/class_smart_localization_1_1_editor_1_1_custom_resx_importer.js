var class_smart_localization_1_1_editor_1_1_custom_resx_importer =
[
    [ "OnPostprocessAllAssets", "class_smart_localization_1_1_editor_1_1_custom_resx_importer.html#af4cc7b3ca305b11d9ece23747aaa6045", null ]
];