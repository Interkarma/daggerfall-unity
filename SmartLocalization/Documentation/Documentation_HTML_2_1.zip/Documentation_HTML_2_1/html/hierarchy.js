var hierarchy =
[
    [ "SmartLocalization.Editor.AndroidStorePresenceGenerator", "class_smart_localization_1_1_editor_1_1_android_store_presence_generator.html", null ],
    [ "AssetPostprocessor", null, [
      [ "SmartLocalization.Editor.CustomResxImporter", "class_smart_localization_1_1_editor_1_1_custom_resx_importer.html", null ]
    ] ],
    [ "SmartLocalization.Editor.CSVExporter", "class_smart_localization_1_1_editor_1_1_c_s_v_exporter.html", null ],
    [ "SmartLocalization.Editor.DirectoryUtility", "class_smart_localization_1_1_editor_1_1_directory_utility.html", null ],
    [ "Editor", null, [
      [ "SmartLocalization.Editor.LocalizedAudioSourceInspector", "class_smart_localization_1_1_editor_1_1_localized_audio_source_inspector.html", null ],
      [ "SmartLocalization.Editor.LocalizedGUITextInspector", "class_smart_localization_1_1_editor_1_1_localized_g_u_i_text_inspector.html", null ],
      [ "SmartLocalization.Editor.LocalizedGUITextureInspector", "class_smart_localization_1_1_editor_1_1_localized_g_u_i_texture_inspector.html", null ]
    ] ],
    [ "EditorWindow", null, [
      [ "SmartLocalization.Editor.CSVExportWindow", "class_smart_localization_1_1_editor_1_1_c_s_v_export_window.html", null ],
      [ "SmartLocalization.Editor.CSVImportWindow", "class_smart_localization_1_1_editor_1_1_c_s_v_import_window.html", null ],
      [ "SmartLocalization.Editor.CSVUpdateWindow", "class_smart_localization_1_1_editor_1_1_c_s_v_update_window.html", null ],
      [ "SmartLocalization.Editor.EditRootLanguageFileWindow", "class_smart_localization_1_1_editor_1_1_edit_root_language_file_window.html", null ],
      [ "SmartLocalization.Editor.SmartLocalizationWindow", "class_smart_localization_1_1_editor_1_1_smart_localization_window.html", null ],
      [ "SmartLocalization.Editor.TranslateLanguageWindow", "class_smart_localization_1_1_editor_1_1_translate_language_window.html", null ]
    ] ],
    [ "SmartLocalization.Editor.FileUtility", "class_smart_localization_1_1_editor_1_1_file_utility.html", null ],
    [ "SmartLocalization.Editor.IAutomaticTranslator", "interface_smart_localization_1_1_editor_1_1_i_automatic_translator.html", [
      [ "SmartLocalization.Editor.MicrosoftAutomaticTranslator", "class_smart_localization_1_1_editor_1_1_microsoft_automatic_translator.html", null ]
    ] ],
    [ "SmartLocalization.Editor.IOSStorePresenceGenerator", "class_smart_localization_1_1_editor_1_1_i_o_s_store_presence_generator.html", null ],
    [ "SmartLocalization.Editor.LanguageDictionaryHelper", "class_smart_localization_1_1_editor_1_1_language_dictionary_helper.html", null ],
    [ "SmartLocalization.Editor.LanguageHandlerEditor", "class_smart_localization_1_1_editor_1_1_language_handler_editor.html", null ],
    [ "SmartLocalization.LanguageParser", "class_smart_localization_1_1_language_parser.html", null ],
    [ "SmartLocalization.LanguageRuntimeData", "class_smart_localization_1_1_language_runtime_data.html", null ],
    [ "SmartLocalization.Editor.LocalizationWindowUtility", "class_smart_localization_1_1_editor_1_1_localization_window_utility.html", null ],
    [ "SmartLocalization.Editor.LocalizationWorkspace", "class_smart_localization_1_1_editor_1_1_localization_workspace.html", null ],
    [ "SmartLocalization.Editor.LocalizedKeySelector", "class_smart_localization_1_1_editor_1_1_localized_key_selector.html", null ],
    [ "SmartLocalization.LocalizedObject", "class_smart_localization_1_1_localized_object.html", null ],
    [ "MonoBehaviour", null, [
      [ "SmartLocalization.LanguageManager", "class_smart_localization_1_1_language_manager.html", null ],
      [ "SmartLocalization.LocalizedAudioSource", "class_smart_localization_1_1_localized_audio_source.html", null ],
      [ "SmartLocalization.LocalizedGUIText", "class_smart_localization_1_1_localized_g_u_i_text.html", null ],
      [ "SmartLocalization.LocalizedGUITexture", "class_smart_localization_1_1_localized_g_u_i_texture.html", null ]
    ] ],
    [ "SmartLocalization.Editor.SerializableLocalizationObjectPair", "class_smart_localization_1_1_editor_1_1_serializable_localization_object_pair.html", null ],
    [ "SmartLocalization.Editor.SerializableStringPair", "class_smart_localization_1_1_editor_1_1_serializable_string_pair.html", null ],
    [ "SmartLocalization.SmartCultureInfo", "class_smart_localization_1_1_smart_culture_info.html", null ],
    [ "SmartLocalization.SmartCultureInfoCollection", "class_smart_localization_1_1_smart_culture_info_collection.html", null ],
    [ "SmartLocalization.Editor.SmartCultureInfoEx", "class_smart_localization_1_1_editor_1_1_smart_culture_info_ex.html", null ],
    [ "SmartLocalization.Editor.StringExtensions", "class_smart_localization_1_1_editor_1_1_string_extensions.html", null ]
];