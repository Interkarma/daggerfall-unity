var class_smart_localization_1_1_editor_1_1_translate_language_window =
[
    [ "Initialize", "class_smart_localization_1_1_editor_1_1_translate_language_window.html#a722a751821dfa9358879eba669c17989", null ],
    [ "InitializeLanguage", "class_smart_localization_1_1_editor_1_1_translate_language_window.html#a100d2ff0c959aacf186b6aa4d77c3dc8", null ],
    [ "InitializeTranslator", "class_smart_localization_1_1_editor_1_1_translate_language_window.html#a98161d34ce07374718ae456e78fbf618", null ],
    [ "ShowWindow", "class_smart_localization_1_1_editor_1_1_translate_language_window.html#a45d0e975899be5397de35d071f5ad390", null ],
    [ "automaticTranslator", "class_smart_localization_1_1_editor_1_1_translate_language_window.html#a64594a39177d1808af7a2886b12f4ba1", null ]
];