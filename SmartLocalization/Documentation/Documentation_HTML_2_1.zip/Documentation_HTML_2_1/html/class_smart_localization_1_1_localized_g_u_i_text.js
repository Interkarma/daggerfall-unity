var class_smart_localization_1_1_localized_g_u_i_text =
[
    [ "localizedKey", "class_smart_localization_1_1_localized_g_u_i_text.html#a20607779108e5fe15a684a7e5ae5fbf7", null ]
];