var class_smart_localization_1_1_smart_culture_info =
[
    [ "SmartCultureInfo", "class_smart_localization_1_1_smart_culture_info.html#afbe949b774cbed3331d91e72e29adf94", null ],
    [ "SmartCultureInfo", "class_smart_localization_1_1_smart_culture_info.html#a7d7c852b2a798a38f4cc4b64c445ea73", null ],
    [ "englishName", "class_smart_localization_1_1_smart_culture_info.html#a089a5441263292f81bf4ff2c557fecb1", null ],
    [ "languageCode", "class_smart_localization_1_1_smart_culture_info.html#ad6c36dc10feef7bc947b6fe679ea4486", null ],
    [ "nativeName", "class_smart_localization_1_1_smart_culture_info.html#aabd10ea163d66641540d09ed1e24025f", null ]
];