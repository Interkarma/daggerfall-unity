var NAVTREEINDEX1 =
{
"namespace_smart_localization_1_1_editor_1_1_mini_j_s_o_n.html":[1,0,0,0,0],
"namespace_smart_localization_1_1_editor_1_1_mini_j_s_o_n.html":[0,0,0,0,0],
"namespacemembers.html":[0,1,0],
"namespacemembers_enum.html":[0,1,2],
"namespacemembers_eval.html":[0,1,3],
"namespacemembers_func.html":[0,1,1],
"namespaces.html":[0,0],
"pages.html":[]
};
