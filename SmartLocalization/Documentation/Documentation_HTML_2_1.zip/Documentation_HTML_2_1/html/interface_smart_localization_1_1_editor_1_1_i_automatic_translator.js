var interface_smart_localization_1_1_editor_1_1_i_automatic_translator =
[
    [ "GetAvailableTranslationLanguages", "interface_smart_localization_1_1_editor_1_1_i_automatic_translator.html#a31141b982bfa45d1e12ff02f61eb43ad", null ],
    [ "Initialize", "interface_smart_localization_1_1_editor_1_1_i_automatic_translator.html#a231ef7b1c1e48d097ad2feefd000cbbb", null ],
    [ "TranslateText", "interface_smart_localization_1_1_editor_1_1_i_automatic_translator.html#a9dc6bf513b6a5da5e8d658129e6e8e13", null ],
    [ "TranslateTextArray", "interface_smart_localization_1_1_editor_1_1_i_automatic_translator.html#a8c6405dc510671d5ed92099456f0e42c", null ],
    [ "InitializationDidExpire", "interface_smart_localization_1_1_editor_1_1_i_automatic_translator.html#ac9742669b5266cd30091256848722762", null ],
    [ "IsInitialized", "interface_smart_localization_1_1_editor_1_1_i_automatic_translator.html#a348e6cfec54bcc462c61541bcca48ed7", null ],
    [ "IsInitializing", "interface_smart_localization_1_1_editor_1_1_i_automatic_translator.html#a657bb5d7acd686b1cc0f561f72febb16", null ]
];